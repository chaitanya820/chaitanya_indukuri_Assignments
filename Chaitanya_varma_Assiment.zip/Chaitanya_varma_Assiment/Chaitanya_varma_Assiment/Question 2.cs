﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Write a program in C# Sharp for a 2D array of size 3x3 and print the matrix

namespace Chaitanya_varma_Assiment
{
    internal class Question_2
    {
        class Program
        {
            static void Main(string[] args)
            { 
                int[,] matrix = new int[3, 3]
                {
                     { 1, 4, 3 },
                     { 4, 6, 32 },
                     { 7, 14, 9 }
                };
                Console.WriteLine("The 3x3 Matrix is:");
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        Console.Write(matrix[i, j] + "\t");
                    }
                    Console.WriteLine();
                }
            }
        }


    }
}
