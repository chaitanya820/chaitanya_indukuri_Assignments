﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Chaitanya_varma_Assiment
{
    //Write a program to create a class called Car with Model, Year of making details. 

    // Read the Car details from the User and store into a file

    public class Car  //class
    {
        public string Model { get; set; }
        public int year_of_Making { get; set; }

        public Car(string model, int year_of_Making)  //  constructor
        {
            Model = model;
            year_of_Making = year_of_Making;
        }

        static void Main() //main function
        {
            Console.WriteLine("Enter the car model:");
            string model = Console.ReadLine();

            Console.WriteLine("Enter the year of making:");
            int yearOfMaking = Convert.ToInt32(Console.ReadLine());

            Car car = new Car(model, yearOfMaking);

            try
            {

                string filePath = "carDetails.txt";
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    writer.WriteLine($"Model: {car.Model}");
                    writer.WriteLine($"Year of Making: {car.year_of_Making}");
                }

                Console.WriteLine("Car details saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }
    }
}
 







